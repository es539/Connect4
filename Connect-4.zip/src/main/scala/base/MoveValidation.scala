package base

class MoveValidation(s: State, v: Boolean) {
  var state: State = s
  var valid: Boolean = v
}
