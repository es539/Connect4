package base

trait GameEn extends Enumeration {
  type pType = Value
}
